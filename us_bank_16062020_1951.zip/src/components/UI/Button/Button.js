import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import Style from "./Button.css";

const Button = (props) => {
  return <button className={Style.Button}>Login</button>;
};

export default Button;
