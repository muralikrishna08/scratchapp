import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.css";
import Input from "../../components/UI/Input/Input";
//import Button from "../../components/UI/Button/Button";
// import Logo from "../../components/Logo/Logo";
import Aux from "react-aux";
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import "./Login.css";
import Dashboard from "../Dashboard/Dashboard";
import BusinessCategory from "../Dashboard/BusinessCategory/BusinessCategory";
// import Searchsuggestion from "../Searchsuggestion/Searchsuggestion";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import ContactCenter from "../Dashboard/ContactCenter/ContactCenter";
import Editheirarchy from "../Dashboard/EditHeirarchy/EditHeirarchy";
import EditHistory from "../Dashboard/EditHistory/EditHistory";
import ViewRecord from "../Dashboard/ViewRecord/ViewRecord";
import {heirarchyData} from '../../sharedfiles/heirarchyData';
import Validator from 'validatorjs';

class Login extends Component {
  constructor(){
    super();
    this.state={data:heirarchyData,loginFields:{userName:"",password:""},loginError:""}
  }
  loginUser(){
    var rules = {
      userName:'required|min:8',
      password:'required|min:8',
    };
    var validation = new Validator(this.state.loginFields, rules,{
      "required.userName":"Please enter userName",
      "required.password":"Please enter Password",
    });
    if(validation.passes()){
      if(this.state.loginFields.password === '123456789'){
        switch(this.state.loginFields.userName){
          case 'power@test.com':
            this.props.history.push("/businesscategory");
            break;
          case 'branch@test.com':
            this.props.history.push("/dashboard");
            break;
          case 'contact@test.com':
            this.props.history.push("/contactcenter");
            break;
          default:
            this.setState({loginError:"Invalid user name or password"});
        }
      }else{
        this.setState({loginError:"Invalid user name or password"})
      }
      
    }else{
      if(validation.errors.has('userName') && validation.errors.get("userName").length>0){
        this.setState({loginError:validation.errors.get("userName")[0]})
      }else if(validation.errors.has('password') && validation.errors.get("password").length>0){
        this.setState({loginError:validation.errors.get("password")[0]})
      }
    }
  }
  updateRecord(index,updatedData){
    debugger;
    console.log("index==",index)
    var data = this.state.data;
    if(index<data.length && Object.keys(updatedData).length>0){
      data[parseInt(index)] = updatedData;
      this.setState({data})
      alert("Changes saved successfully.");
    }
  }
  fieldChanged(field, e){
    console.log(field,"===",e.target.value)
    var loginFields = this.state.loginFields;
    loginFields[field] = e.target.value;
    this.setState({loginFields,loginError:""})
  }
  render() {
    console.log("heirarchyData==",this.state.data)
    return (
      <Aux>
            <Route exact path="/">
              <Header></Header>
              <div className="otercontainerlogin">
                <div className="headingproject">
                  <h2>
                    Sample Management <span style={{ color: "#000" }}>&</span>{" "}
                    <span style={{ color: "#d62948" }}>Data Query System</span>
                  </h2>
                </div>
                <div className="containerlogin">
                  <div className="outercontainer">
                    {/* <Logo /> */}
                    <div>
                      <div>
                        <label className="labelColor">Username</label>
                      </div>
                      <input className="form-control" type="text" value={this.state.loginFields.userName} onChange={this.fieldChanged.bind(this,'userName')}/>
                    </div>
                    <div>
                      <div>
                        <label className="labelColor">Password</label>
                      </div>
                      <input className="form-control" type="password" value={this.state.loginFields.password} onChange={this.fieldChanged.bind(this,'password')}/>
                    </div>
                      <div className="error-msg">{this.state.loginError}</div>
                    <div className="loginbutton">
                      {/* <Button /> */}
                      <a onClick={this.loginUser.bind(this)}>LogIn</a>
                      {/*<Link to="/dashboard">LogIn as Branch User</Link>
                      <Link to="/contactcenter">LogIn as Contact Center</Link>*/}
                    </div>
                  </div>
                </div>
              </div>
              <Footer></Footer>
            </Route>
            <Route exact path="/dashboard" render={(props)=><Dashboard {...props} data={this.state.data} loginState={this}/>}/>

            <Route path="/businesscategory">
              <BusinessCategory />
            </Route>
            <Route path="/contactcenter">
              <ContactCenter />
            </Route>
            <Route path="/editheirarchy">
              <Editheirarchy data={this.state.data} loginState={this}/>
            </Route>
            <Route path="/EditHistory">
              <EditHistory />
            </Route>
            <Route path="/ViewRecord">
              <ViewRecord data={this.state.data}/>
            </Route>
      </Aux>
    );
  }
}

export default Login;
