import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.css";
import Aux from "react-aux";
import Header from "../../../components/Header/Header";
import "./Editheirarchy.css";
import cookie from 'react-cookies';
import { Link } from "react-router-dom";
import Validator from 'validatorjs';

class Editheirarchy extends Component{
  constructor(props){
    super(props)
    this.state={data:{}, 
    viewtype : null,
    errorsMgs : {
      STARTDT: "",
      ENDDT: "",
      CHANNEL: "",
      ROUTE: "",
      USB_MODE: "",
      LOGIN: "",
    }
  }
  }

  componentDidMount(){
    let id = this.getQueryVariable('id');
    let viewtype = this.getQueryVariable('view');
    console.log(viewtype)
    let editData = this.props.data;
    if(editData && editData.length>0 && parseInt(id) < editData.length){
      this.setState({data:editData[id]});
      this.setState({'viewtype' : viewtype});
    }
  }
  getQueryVariable(variable){
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
      var pair = vars[i].split("=");
      if(pair[0] == variable){return pair[1];}
    }
    return(false);
  }
  fieldChanged(field, e){
    console.log(field,"===",e.target.value)
    var data = this.state.data;
    var errorsMgs = this.state.errorsMgs;
    data[field] = e.target.value;
    errorsMgs[field] = "";
    this.setState({data})
  }
  saveChanges(){
    var rules = {
      STARTDT: "required",
      ENDDT: "required",
      CHANNEL: "required",
      ROUTE: "required",
      USB_MODE: "required",
      LOGIN: "required",
    };
    // var validation = new Validator(this.state.data, rules,{
    //   "required.STARTDT":"Please enter STARTDT",
    // });
    var validation = new Validator(this.state.data, rules);
    if (validation.passes()) {
      let id = this.getQueryVariable('id');
      let cookieData = cookie.load("branchData");
      this.props.loginState.updateRecord(id,this.state.data)
    } else {
      var errorsMgs = {
        STARTDT: "",
        ENDDT: "",
        CHANNEL: "",
        ROUTE: "",
        USB_MODE: "",
        LOGIN: "",
      }
      if(validation.errors.has('STARTDT') && validation.errors.get("STARTDT").length>0){
        errorsMgs.STARTDT = validation.errors.get("STARTDT")[0]
      }
      if(validation.errors.has('ENDDT') && validation.errors.get("ENDDT").length>0){
        errorsMgs.ENDDT = validation.errors.get("ENDDT")[0]
      }
      if(validation.errors.has('CHANNEL') && validation.errors.get("CHANNEL").length>0){
        errorsMgs.CHANNEL = validation.errors.get("CHANNEL")[0]
      }
      if(validation.errors.has('ROUTE') && validation.errors.get("ROUTE").length>0){
        errorsMgs.ROUTE = validation.errors.get("ROUTE")[0]
      }
      if(validation.errors.has('USB_MODE') && validation.errors.get("USB_MODE").length>0){
        errorsMgs.USB_MODE = validation.errors.get("USB_MODE")[0]
      }
      if(validation.errors.has('LOGIN') && validation.errors.get("LOGIN").length>0){
        errorsMgs.LOGIN = validation.errors.get("LOGIN")[0]
      }
      this.setState({errorsMgs})
    }
    
    // if(cookieData && cookieData.length>0 && parseInt(id) < cookieData.length){
    //   cookieData[id] = this.state.data;
    //   cookie.save("branchData",cookieData);
    //   alert("Changes saved successfully.");
    // }
    return false;
  }
  render(){
    return (
      <Aux>
        <Header></Header>
        <Link to="/dashboard">back</Link>
        <div style={{ padding: "50px" }}>
          <h2>{this.state.viewtype ==='viewonly' ?  'View' : 'Edit'}</h2>
          <form className="form-horizontal" action="return false">
            <div className="form-group">
              <label htmlFor="inputEmail3" className="col-sm-2 control-label">
                StartDT
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.STARTDT.length>0?" error-textfiled":"")}
                  placeholder="Start DT"
                  value={this.state.data.STARTDT || ''}
                  readOnly={this.state.viewtype === 'viewonly'}
                  onChange={this.fieldChanged.bind(this,'STARTDT')}
                />
                <div className="error-msg">{this.state.errorsMgs.STARTDT}</div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="inputPassword3" className="col-sm-2 control-label">
                EndDT
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.ENDDT.length>0?" error-textfiled":"")}
                  placeholder="End DT"
                  readOnly={this.state.viewtype === 'viewonly'}
                  value={this.state.data.ENDDT || ''}
                  onChange={this.fieldChanged.bind(this,'ENDDT')}
                />
                <div className="error-msg">{this.state.errorsMgs.ENDDT}</div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="inputPassword3" className="col-sm-2 control-label">
                Channel
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.CHANNEL.length>0?" error-textfiled":"")}
                  placeholder="Channel"
                  readOnly={this.state.viewtype === 'viewonly'}
                  value={this.state.data.CHANNEL || ''}
                  onChange={this.fieldChanged.bind(this,'CHANNEL')}
                />
                <div className="error-msg">{this.state.errorsMgs.CHANNEL}</div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="inputPassword3" className="col-sm-2 control-label">
                Route 
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.ROUTE.length>0?" error-textfiled":"")}
                  placeholder="Route"
                  readOnly={this.state.viewtype === 'viewonly'}
                  value={this.state.data.ROUTE || ''}
                  onChange={this.fieldChanged.bind(this,'ROUTE')}
                />
                <div className="error-msg">{this.state.errorsMgs.ROUTE}</div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="inputPassword3" className="col-sm-2 control-label">
                USB Mode
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.USB_MODE.length>0?" error-textfiled":"")}
                  placeholder="USB Mode"
                  readOnly={this.state.viewtype === 'viewonly'}
                  value={this.state.data.USB_MODE || '' }
                  onChange={this.fieldChanged.bind(this,'USB_MODE')}
                />
                <div className="error-msg">{this.state.errorsMgs.USB_MODE}</div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="inputPassword3" className="col-sm-2 control-label">
                Login
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className={"form-control"+(this.state.errorsMgs.LOGIN.length>0?" error-textfiled":"")}
                  placeholder="Login"
                  readOnly={this.state.viewtype === 'viewonly'}
                  value={this.state.data.LOGIN || ''}
                  onChange={this.fieldChanged.bind(this,'LOGIN')}
                />
                <div className="error-msg">{this.state.errorsMgs.LOGIN}</div>
              </div>
            </div>
  {this.state.viewtype === 'viewonly' ? '' :
            <div className="form-group">
              <div className="col-sm-offset-2 col-sm-10">
                <button
                  type="button"
                  className="btn btn-default"
                  style={{ marginRight: "10px" }}
                  onClick={this.saveChanges.bind(this)}
                >
                  Save
                </button>
                <button style={{ marginRight: "10px" }}className="btn btn-default">
                  Cancel
                </button>
                <button type="button" style={{ marginRight: "10px" }} className="btn btn-default">
                                  Import to Qualtrics
                                </button>
              </div>
            </div>
            }
          </form>
        </div>
      </Aux>
    );
  }
  
};

export default Editheirarchy;
