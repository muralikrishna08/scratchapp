import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import Img from "../../assets/images/usbank.png";

const Button = (props) => {
  return <img alt="" title="" src={Img}></img>;
};

export default Button;
