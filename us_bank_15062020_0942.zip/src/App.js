import React, { Component } from "react";
import Login from "./containers/Login/Login";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import "./App.css";
class App extends Component {
  render() {
    return <Router>
       <Switch>
          <Route render={(props)=><Login {...props}/>}/>
       </Switch>
    </Router>
    // return <div>hello</div>;
  }
}

export default App;
