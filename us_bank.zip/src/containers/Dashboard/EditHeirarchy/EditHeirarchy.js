import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.css";
import Aux from "react-aux";
import Header from "../../../components/Header/Header";
import "./Editheirarchy.css";
import cookie from 'react-cookies';

class Editheirarchy extends Component{
  constructor(props){
    super(props)
    this.state={data:{}}
  }
  componentDidMount(){
    let id = this.getQueryVariable('id');
    let cookieData = cookie.load("branchData");
    if(cookieData && cookieData.length>0 && parseInt(id) < cookieData.length){
      this.setState({data:cookieData[id]});
    }
  }
  getQueryVariable(variable){
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
      var pair = vars[i].split("=");
      if(pair[0] == variable){return pair[1];}
    }
    return(false);
  }
  fieldChanged(field, e){
    console.log(field,"===",e.target.value)
    var data = this.state.data;
    data[field] = e.target.value;
    this.setState({data})
  }
  saveChanges(){
    let id = this.getQueryVariable('id');
    let cookieData = cookie.load("branchData");
    if(cookieData && cookieData.length>0 && parseInt(id) < cookieData.length){
      cookieData[id] = this.state.data;
      cookie.save("branchData",cookieData);
      alert("Changes saved successfully.");
    }
    return false;
  }
  render(){
    return (
      <Aux>
        <Header></Header>
        <div style={{ padding: "50px" }}>
          <h2>Edit</h2>
          <form class="form-horizontal" action="return false">
            <div class="form-group">
              <label for="inputEmail3" class="col-sm-2 control-label">
                StartDT
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Start DT"
                  value={this.state.data.STARTDT}
                  onChange={this.fieldChanged.bind(this,'STARTDT')}
                />
              </div>
            </div>
            <div class="form-group">
              <label for="inputPassword3" class="col-sm-2 control-label">
                EndDT
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="End DT"
                  value={this.state.data.ENDDT}
                  onChange={this.fieldChanged.bind(this,'ENDDT')}
                />
              </div>
            </div>
            <div class="form-group">
              <label for="inputPassword3" class="col-sm-2 control-label">
                Channel
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Channel"
                  value={this.state.data.CHANNEL}
                  onChange={this.fieldChanged.bind(this,'CHANNEL')}
                />
              </div>
            </div>
            <div class="form-group">
              <label for="inputPassword3" class="col-sm-2 control-label">
                Route 
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Route"
                  value={this.state.data.ROUTE}
                  onChange={this.fieldChanged.bind(this,'ROUTE')}
                />
              </div>
            </div>
            <div class="form-group">
              <label for="inputPassword3" class="col-sm-2 control-label">
                USB Mode
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="USB Mode"
                  value={this.state.data.USB_MODE}
                  onChange={this.fieldChanged.bind(this,'USB_MODE')}
                />
              </div>
            </div>
            <div class="form-group">
              <label for="inputPassword3" class="col-sm-2 control-label">
                Login
              </label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Login"
                  value={this.state.data.LOGIN}
                  onChange={this.fieldChanged.bind(this,'LOGIN')}
                />
              </div>
            </div>
  
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button
                  type="button"
                  class="btn btn-default"
                  style={{ marginRight: "10px" }}
                  onClick={this.saveChanges.bind(this)}
                >
                  Save
                </button>
                <button class="btn btn-default">
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
      </Aux>
    );
  }
  
};

export default Editheirarchy;
