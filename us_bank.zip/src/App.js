import React, { Component } from "react";
import Login from "./containers/Login/Login";
import "./App.css";
class App extends Component {
  render() {
    return <Login></Login>;
    // return <div>hello</div>;
  }
}

export default App;
